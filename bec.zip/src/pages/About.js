const About = () => {
    return <h1>Sobre Nosotros</h1>;
  };
  
  export default About;