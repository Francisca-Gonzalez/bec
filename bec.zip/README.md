# bec

## Instalación y uso
* npm install react-router-dom axios
* npm start
